# bakery-orders

Order totals for Crumb & Co. The shop till exports a CSV of every order line;
this script adds them up per order so Maria (the owner) can check the till
and send invoices to trade customers. For each order it prints the total
before VAT, the VAT, and the total with VAT, then the same three for all orders.

## Run it

    python3 orders.py data/orders_october.csv

## Test it

    python3 -m unittest

## The CSV

One row per order line: `order_id,date,customer,item,quantity,unit_price`.
Prices are in pounds, before VAT.

The newer till export (from November 2026) adds a `unit` column after `item`:
`each`, or `dozen`. For `dozen`, the quantity is in dozens and the price is per
dozen. Older exports with no `unit` column are read as `each`. Any other unit
stops the script with an error, rather than give a wrong total.

## Bulk discount

Any order line with 12 or more of the same item gets 10% off that line.
Dozens count as 12 items, so 2 dozen croissants (24) get the discount. It
applies to every customer, trade or not.

## VAT

VAT is added to each order's total after the bulk discount comes off, which
is how the till does it.

The rate is 20% for now. **This is provisional**: Maria is checking the rate
with her accountant. To change it, edit `VAT_RATE` near the top of `orders.py`.

## Money and rounding

All money is handled as exact decimal amounts, never floating-point numbers,
so totals don't drift by a penny. Amounts are rounded to the penny with halves
going up (2.025 becomes 2.03), like the till: each order's total before VAT is
rounded, then the VAT on it is rounded.

## Not done yet

- A daily summary Maria can print
