# Order totals: discount, VAT, daily summary — handover 2026-11-11 14:15

- Project / branch: bakery-orders / bulk-discount
- Person: Jordan, who looks after this script for Crumb & Co and merges branches into main himself
- Others mentioned: Maria: owner of Crumb & Co, the bakery; Maria's accountant: is checking the VAT rate and asked for decimal money rounded like the till
- Tool: Claude Code
- Models: Opus 5.5 (claude-opus-5-5); no helper agents
- Versions: handbook "Last changed" 2026-11-11; skills: handover 1.1

## Next

The overall job is three things: the bulk discount, VAT, and a daily summary Maria can print. The first two are done on `bulk-discount`. The daily summary is tomorrow's work and has not been started.

State:
- Bulk discount: 10% off any order line with 12 or more items; "dozen" lines count as 12 items each — verified: `python3 -m unittest` (16 tests, all pass)
- The discount applies to every customer, trade or walk-in (for example, walk-in order 1010 in October) — stated: by Jordan, "leave it as the rule says"
- VAT is added after the discount, as the till does it — stated: by Jordan
- VAT rate is 20%, PROVISIONAL until Maria's accountant confirms it; set by `VAT_RATE` in `orders.py` — stated: by Jordan
- All money is `Decimal`, rounded half-up to the penny — verified: `python3 -m unittest` (includes a 2.025 → 2.03 test)
- October: before VAT 217.96, VAT 43.59, with VAT 261.55 — verified: `python3 orders.py data/orders_october.csv`
- November: before VAT 138.21, VAT 27.64, with VAT 165.85 — verified: `python3 orders.py data/orders_november.csv`
- Branch has 4 commits not in main (37d8b9f, cb0d3af, 4988d4f, 842a66b) plus this note — verified: `git log --oneline main..bulk-discount`
- README.md is edited but deliberately NOT committed; Jordan wants to read the wording first — verified: `git status --short` shows ` M README.md`
- Whether the till works out VAT per order (as the script does) or per line is unknown. If per line, some orders could be 1p out. Order 1004 is the one most likely to show a difference: before rounding, its total before VAT is exactly 33.975.

First step: check what Jordan did overnight (see his steps below), then start the daily summary.
Don't redo: the discount, the dozen handling, VAT, or the switch to Decimal. All are committed and tested.
Read first: `orders.py`, `tests/test_orders.py`, `README.md` (including the uncommitted change: `git diff README.md`)
Outside the project: none needed. `../outside/task1/oct_float.txt` and `../outside/task1/nov_float.txt` are this session's scratch output from the old float version, used only for comparison; they can be thrown away. November's export, `../outside/task1/orders_november.csv`, has already been copied into `data/`.

AI next steps:
1. Run `git status --short`, `git log --oneline -6` and `git branch --merged main` to see whether Jordan committed the README and merged `bulk-discount`. Don't commit the README yourself.
2. Ask Jordan only what the files can't answer: has Maria's accountant confirmed the VAT rate, and are there real till receipts to compare with (ideally orders 1004 or 1107)?
3. Ask Jordan what the daily summary should show and how Maria will print it before building it. Nothing about its contents was decided today.

Person's next steps (paste in order; the AI does not run these). Next session: ask whether each is done.
1. `git diff README.md` (read the wording)
2. `git add README.md && git commit -m "Describe bulk discount, VAT and rounding in README"` (only if happy with it)
3. `git checkout main && git merge bulk-discount` (only once Maria is happy)

## Why

- Changed: added the bulk discount, support for the new till's `unit` column (each or dozen), VAT, and exact decimal money. Added November's export as `data/orders_november.csv` so the tests cover both till formats. The output now shows, for each order, the total before VAT, the VAT and the total with VAT, then the same three for all orders.
- Decided: discount before VAT (Jordan, matching the till). VAT is worked out on each order's rounded total before VAT. Rounding is half-up to the penny (Jordan, at the accountant's request). An unknown `unit` value stops the script with an error, rather than give a wrong total (the AI's call). Handover notes are committed to git (Jordan).
- Tried and dropped: plain floats with `round(x, 2)`. Jordan first said they were fine, then the accountant ruled them out. Floats give 2.02 for 2.025, where the till gives 2.03.

## What went wrong

Previous note: none (this is the first note in the project).

- Corrections from the person: the discount was reported done but missed dozen lines from the new till (Jordan supplied November's export showing order 1107); floats replaced by Decimal at the accountant's request.
- Took more than one try: the November total in a test was first written as 154.30 from my own arithmetic; the real total is 138.21 (checked line by line). The test caught it before commit.
- Worked well: making each new test fail against the old code before trusting it; comparing the Decimal output line by line with the float output for both months.

### Lesson: "done" tested against one sample file only
- What happened: I reported the bulk discount done after testing only October's export. The new till's November export has a `unit` column, so 2 dozen croissants (order 1107) counted as 2 items and got no discount.
- Lesson: before calling data-handling work done, ask whether other export formats or newer samples exist, and test every one that does.
- Applies when / doesn't apply when: code that reads files from an outside system (till, bank, form exports) / pure logic with no outside input.
- Caught by: Jordan
- Severity: serious (totals were quietly wrong)
- Belongs in: global instructions
- Seen before: none
