"""Order totals for Crumb & Co, a small bakery.

Reads an orders CSV exported from the shop till and prints, for each order,
the total before VAT (after any bulk discount), the VAT and the total with
VAT, then the grand totals.

Usage:
    python3 orders.py data/orders_october.csv
"""
import csv
import sys
from decimal import ROUND_HALF_UP, Decimal

PENNY = Decimal("0.01")

# Bulk discount: 10% off any order line with this many or more of one item.
BULK_MIN_QUANTITY = 12
BULK_DISCOUNT = Decimal("0.10")

# VAT rate. PROVISIONAL: 20% until Maria's accountant confirms the rate.
# Change it here; nothing else needs to change.
VAT_RATE = Decimal("0.20")

# How many items one unit of quantity stands for. The October till export has
# no unit column, so a missing unit means "each".
ITEMS_PER_UNIT = {"each": 1, "dozen": 12}


def load_orders(path):
    """Read the till export. Returns a list of dicts, one per order line."""
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        row["quantity"] = int(row["quantity"])
        row["unit_price"] = Decimal(row["unit_price"])
    return rows


def to_penny(amount):
    """Round money to the penny, halves going up (2.025 becomes 2.03), like the till."""
    return amount.quantize(PENNY, rounding=ROUND_HALF_UP)


def item_count(row):
    """Number of single items on a line (2 dozen is 24)."""
    unit = row.get("unit") or "each"
    if unit not in ITEMS_PER_UNIT:
        raise ValueError(f"Unknown unit {unit!r} on order {row.get('order_id')}")
    return row["quantity"] * ITEMS_PER_UNIT[unit]


def line_total(row):
    """Price for one order line, after any bulk discount.

    unit_price is the price per unit (per dozen if the unit is "dozen"), as a
    Decimal. The result is exact, not rounded; order_totals rounds.
    """
    total = row["quantity"] * row["unit_price"]
    if item_count(row) >= BULK_MIN_QUANTITY:
        total *= 1 - BULK_DISCOUNT
    return total


def order_totals(rows):
    """Total per order id before VAT, rounded half-up to the penny."""
    totals = {}
    for row in rows:
        totals[row["order_id"]] = totals.get(row["order_id"], Decimal(0)) + line_total(row)
    return {order_id: to_penny(total) for order_id, total in totals.items()}


def with_vat(net):
    """VAT on an order's net total (after discount), rounded to the penny.

    The discount comes off first, then VAT is added, as the till does it.
    Returns (vat, total including VAT).
    """
    vat = to_penny(net * VAT_RATE)
    return vat, net + vat


def main(argv):
    if len(argv) != 2:
        print(__doc__)
        return 2
    totals = order_totals(load_orders(argv[1]))
    print(f"{'ORDER':<5} {'NET':>8} {'VAT':>8} {'TOTAL':>8}")
    sum_net = sum_vat = sum_total = Decimal(0)
    for order_id in sorted(totals):
        net = totals[order_id]
        vat, total = with_vat(net)
        sum_net, sum_vat, sum_total = sum_net + net, sum_vat + vat, sum_total + total
        print(f"{order_id:<5} {net:>8.2f} {vat:>8.2f} {total:>8.2f}")
    print(f"{'ALL':<5} {sum_net:>8.2f} {sum_vat:>8.2f} {sum_total:>8.2f}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
