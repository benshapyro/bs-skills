import os
import unittest

from decimal import Decimal as D

import orders

DATA = os.path.join(os.path.dirname(__file__), "..", "data", "orders_october.csv")
NOVEMBER = os.path.join(os.path.dirname(__file__), "..", "data", "orders_november.csv")


class LineTotalTest(unittest.TestCase):
    def test_quantity_times_price(self):
        self.assertEqual(orders.line_total({"quantity": 3, "unit_price": D("2.40")}), D("7.20"))

    def test_no_discount_below_twelve(self):
        self.assertEqual(orders.line_total({"quantity": 11, "unit_price": D("1.95")}), D("21.45"))

    def test_ten_percent_off_at_twelve(self):
        self.assertEqual(orders.line_total({"quantity": 12, "unit_price": D("1.55")}), D("16.74"))

    def test_ten_percent_off_above_twelve(self):
        self.assertEqual(orders.line_total({"quantity": 24, "unit_price": D("1.35")}), D("29.16"))

    def test_two_dozen_counts_as_twenty_four(self):
        row = {"unit": "dozen", "quantity": 2, "unit_price": D("15.00")}
        self.assertEqual(orders.line_total(row), D("27.00"))

    def test_one_dozen_counts_as_twelve(self):
        row = {"unit": "dozen", "quantity": 1, "unit_price": D("7.20")}
        self.assertEqual(orders.line_total(row), D("6.48"))

    def test_each_unit_works_like_no_unit(self):
        row = {"unit": "each", "quantity": 11, "unit_price": D("1.95")}
        self.assertEqual(orders.line_total(row), D("21.45"))

    def test_unknown_unit_is_an_error(self):
        with self.assertRaises(ValueError):
            orders.line_total({"unit": "tray", "quantity": 1, "unit_price": D("9.00")})


class OrderTotalsTest(unittest.TestCase):
    def test_lines_are_summed_per_order(self):
        rows = [
            {"order_id": "1", "quantity": 1, "unit_price": D("4.20")},
            {"order_id": "1", "quantity": 2, "unit_price": D("2.85")},
            {"order_id": "2", "quantity": 1, "unit_price": D("3.90")},
        ]
        self.assertEqual(orders.order_totals(rows), {"1": D("9.90"), "2": D("3.90")})


class RoundingTest(unittest.TestCase):
    def test_half_pennies_round_up(self):
        # 15 x 0.15 = 2.25, less 10% = 2.025. Floats gave 2.02; the till gives 2.03.
        rows = [{"order_id": "1", "quantity": 15, "unit_price": D("0.15")}]
        self.assertEqual(orders.order_totals(rows), {"1": D("2.03")})

    def test_money_is_decimal_not_float(self):
        rows = orders.load_orders(NOVEMBER)
        self.assertIsInstance(rows[0]["unit_price"], D)
        net = orders.order_totals(rows)["1107"]
        vat, total = orders.with_vat(net)
        for amount in (net, vat, total):
            self.assertIsInstance(amount, D)


class VatTest(unittest.TestCase):
    def test_vat_is_added_after_discount(self):
        # 24 croissants at 1.35 = 32.40, less 10% = 29.16, plus 20% VAT.
        net = orders.order_totals([{"order_id": "1", "quantity": 24, "unit_price": D("1.35")}])["1"]
        self.assertEqual(orders.with_vat(net), (D("5.83"), D("34.99")))

    def test_vat_uses_the_rate_setting(self):
        self.assertEqual(orders.VAT_RATE, D("0.20"))
        self.assertEqual(orders.with_vat(D("10.00")), (D("2.00"), D("12.00")))


class LoadOrdersTest(unittest.TestCase):
    def test_october_export_loads(self):
        rows = orders.load_orders(DATA)
        self.assertEqual(len(rows), 15)
        self.assertEqual(rows[0]["quantity"], 1)
        self.assertEqual(rows[0]["unit_price"], D("4.20"))


class MonthTotalsTest(unittest.TestCase):
    def test_october_totals(self):
        totals = orders.order_totals(orders.load_orders(DATA))
        self.assertEqual(totals["1002"], D("45.90"))
        self.assertEqual(totals["1010"], D("7.02"))
        self.assertEqual(sum(totals.values()), D("217.96"))

    def test_november_totals(self):
        totals = orders.order_totals(orders.load_orders(NOVEMBER))
        self.assertEqual(totals["1107"], D("27.00"))
        self.assertEqual(totals["1109"], D("6.48"))
        self.assertEqual(totals["1110"], D("21.45"))
        self.assertEqual(sum(totals.values()), D("138.21"))


if __name__ == "__main__":
    unittest.main()
