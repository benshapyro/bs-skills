# roster-clean

Cleans the volunteer sign-up export for Riverside Food Bank so Dee, the
shift manager, gets one tidy row per person.

## Run

    python3 clean.py INPUT.csv OUTPUT.csv

This also writes `needs_review.csv` next to OUTPUT: rows that share a phone
but have different first names (often family members), for a person to check.

Rows are the same person if they share an email (Gmail addresses compared
the way Gmail reads them: dots ignored, googlemail.com = gmail.com), or share a phone and first
name. Similar names alone never merge. The newest sign-up is kept.

## Test

    python3 -m unittest

## Privacy

Real exports hold people's names, emails and phone numbers. They live outside
this repository and must never be committed. `data/sample_roster.csv` is made
up and is the only roster file in the repo.

## To do

- A per-shift list for Dee
