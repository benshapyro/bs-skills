"""Clean the volunteer sign-up export for Riverside Food Bank.

The sign-up form exports one row per submission. People often sign up twice,
type their name in odd ways, or write phone numbers in different formats.

Two rows are the same person if they have the same email (Gmail addresses
compared the way Gmail reads them), or the same phone
and the same first name. We never merge on similar names: wrongly merging two
people means one of them misses their shift reminder, which is worse than
someone getting two texts. When people merge, the newest sign-up is kept,
because people re-submit to update their shifts.

Rows that share a phone but have different first names (families often share
a phone) are not merged. They go to needs_review.csv, next to OUTPUT, for a
person to check.

Usage:
    python3 clean.py INPUT.csv OUTPUT.csv
"""
import csv
import os
import re
import sys

FIELDS = ["timestamp", "full_name", "email", "phone", "shifts", "notes"]


def normalise_name(name):
    """'  ada   OKAFOR ' -> 'Ada Okafor'."""
    return " ".join(part.capitalize() for part in name.split())


def normalise_email(email):
    return email.strip().lower()


GMAIL_DOMAINS = {"gmail.com", "googlemail.com"}


def email_key(email):
    """The mailbox an address really goes to, for spotting duplicates.

    Gmail ignores dots and anything after '+' before the @, and treats
    googlemail.com as gmail.com. Other providers are compared as written.
    """
    local, at, domain = email.partition("@")
    if at and domain in GMAIL_DOMAINS:
        local = local.split("+")[0].replace(".", "")
        domain = "gmail.com"
    return local + at + domain


def normalise_phone(phone):
    """'+44 (0)7700 900123', '07700-900123' -> '+447700900123'.

    UK numbers only. Anything that doesn't come out as +44 and ten digits is
    returned unchanged (just trimmed), so a person can look at it.
    """
    digits = re.sub(r"\D", "", phone)
    if digits.startswith("44"):
        digits = digits[2:]
    if digits.startswith("0"):
        digits = digits[1:]
    if len(digits) != 10:
        return phone.strip()
    return "+44" + digits


def load(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def clean_rows(rows):
    cleaned = []
    for row in rows:
        row = dict(row)
        row["full_name"] = normalise_name(row["full_name"])
        row["email"] = normalise_email(row["email"])
        row["phone"] = normalise_phone(row["phone"])
        cleaned.append(row)
    return cleaned


def first_name(row):
    parts = row["full_name"].split()
    return parts[0].lower() if parts else ""


def dedupe(rows):
    """Merge duplicate sign-ups in already-cleaned rows.

    Returns (kept, merged, review):
      kept   - one row per person, the newest sign-up, in original order
      merged - list of (kept_row, [dropped rows]) for each merged person
      review - groups of rows sharing a phone with different first names
    """
    parent = list(range(len(rows)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            a, b = rows[i], rows[j]
            same_email = a["email"] and email_key(a["email"]) == email_key(b["email"])
            same_phone = a["phone"] and a["phone"] == b["phone"]
            if same_email or (same_phone and first_name(a) == first_name(b)):
                parent[find(j)] = find(i)

    groups = {}
    for i in range(len(rows)):
        groups.setdefault(find(i), []).append(i)

    keep, merged = set(), []
    for members in groups.values():
        newest = max(members, key=lambda i: (rows[i]["timestamp"], i))
        keep.add(newest)
        if len(members) > 1:
            merged.append((rows[newest], [rows[i] for i in members if i != newest]))
    kept = [rows[i] for i in sorted(keep)]

    by_phone = {}
    for row in kept:
        if row["phone"]:
            by_phone.setdefault(row["phone"], []).append(row)
    review = [g for g in by_phone.values()
              if len({first_name(r) for r in g}) > 1]
    return kept, merged, review


def save(rows, path):
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    rows = clean_rows(load(argv[1]))
    kept, merged, review = dedupe(rows)
    save(kept, argv[2])
    review_path = os.path.join(os.path.dirname(argv[2]), "needs_review.csv")
    save([r for group in review for r in group], review_path)
    print(f"{len(rows)} sign-ups, {len(kept)} volunteers written to {argv[2]}")
    for newest, dropped in merged:
        older = ", ".join(r["timestamp"] for r in dropped)
        print(f"  merged: {newest['full_name']} - kept {newest['timestamp']}, dropped {older}")
    print(f"{len(review)} shared-phone group(s) written to {review_path}")
    for group in review:
        print("  review: " + " / ".join(r["full_name"] for r in group))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
