# Roster cleaning — handover 2026-11-11

- Project / branch: roster-clean / main
- Person: Alex, helps run the volunteers at Riverside Food Bank
- Others mentioned: Dee: shift manager, the person the cleaned list is for. A coordinator agent passed on the duplicate-rule decisions and the go-ahead to commit notes.
- Tool: Claude Code (run as a helper agent)
- Models: Opus 5.5
- Versions: handbook "Last changed" 2026-11-11; skills: handover 1.1

## Next

State:
- Phone numbers come out as `+44` and ten digits; anything else is left as written — verified: `python3 -m unittest` (15 tests, all pass, none skipped)
- Duplicates are removed. Same person = same email (Gmail compared the way Gmail reads it), or same phone and same first name. Similar names alone never merge. Newest sign-up kept — verified: same test run
- Rows sharing a phone with different first names are kept and also written to `needs_review.csv` next to the output — verified: same test run
- The real November export was cleaned: 15 sign-ups, 12 volunteers, 3 merges, 2 shared-phone groups for review — verified: `python3 clean.py ../outside/task3/roster_export_2026-11.csv ../outside/task3/roster_clean.csv`
- Nothing is pushed; no remote checked — unknown whether one exists: run `git remote -v`
- Per-shift list for Dee: not started (Alex said not to start it today) — stated: by Alex

First step: ask Alex what the per-shift list should look like (one file per shift, or one file grouped by shift; which columns Dee needs).
Don't redo: phone formatting, duplicate removal, the November clean run.
Read first: `README.md`, `clean.py`
Outside the project: the real export, the cleaned file and the review list, all in `../outside/task3/` (people's details; never commit them; `.gitignore` covers all three names)

AI next steps:
1. Build the per-shift list from the cleaned rows (the `shifts` column is `; `-separated, e.g. `Sat AM; Sun PM`), with tests on `data/sample_roster.csv`.

Person's next steps (the AI does not run these). Next session: ask whether each is done.
1. Ring the shared-phone households listed in `../outside/task3/needs_review.csv` and say whether any are one person.

## Why

- Changed: added `normalise_phone`, `email_key` and `dedupe` to `clean.py`; `clean.py` now also writes `needs_review.csv`; README updated.
- Decided (Alex, via the coordinator): drop name matching completely. Wrongly merging two people means one misses their shift reminder and doesn't turn up; missing a duplicate only means two texts. Keep the newest sign-up, because people re-submit to update shifts.
- Decided (Alex, via the coordinator): Gmail ignores dots before the @ and treats googlemail.com as gmail.com, so compare those addresses that way. Plus-tags (`name+x@gmail.com`) are also ignored — that part is this session's call, since Gmail delivers them to the same inbox.
- Tried and dropped: Alex's first rule (same email, or same phone, or `difflib` name similarity of 0.8 or more). On the real export it merged two pairs of family members who share a phone and a pair of different people with similar names; on the sample it collapsed all 5 made-up rows into 1.

## What went wrong

Previous note: none (first note in this project)

- Corrections from the person: the duplicate rule changed twice (no name matching, shared phones go to review; then Gmail address matching).
- Worked well: checking the proposed rule against the real data, read-only, before writing any merge code. That caught the wrong merges before anything was written.

### Lesson: fuzzy name matching merges different people
- What happened: the requested 0.8 name-similarity rule would have dropped real volunteers from Dee's list (family members, and names one letter apart).
- Lesson: before building a merge rule, print the pairs it would merge on the real data and show them to the person.
- Applies when / doesn't apply when: any rule that deletes or merges records / not to formatting-only changes.
- Caught by: a dry run on the real export before coding
- Severity: serious (people would have missed shift reminders)
- Belongs in: a project file (the rule is now written in `clean.py` and `README.md`)
- Seen before: none
