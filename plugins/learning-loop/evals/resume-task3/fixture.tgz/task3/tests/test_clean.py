import os
import unittest

import clean

SAMPLE = os.path.join(os.path.dirname(__file__), "..", "data", "sample_roster.csv")


class NameTest(unittest.TestCase):
    def test_spacing_and_case(self):
        self.assertEqual(clean.normalise_name("  test   PERSON three "), "Test Person Three")


class EmailTest(unittest.TestCase):
    def test_lowercase_and_strip(self):
        self.assertEqual(clean.normalise_email(" One.Test@Example.org "), "one.test@example.org")


class EmailKeyTest(unittest.TestCase):
    def test_gmail_dots_plus_and_googlemail(self):
        self.assertEqual(clean.email_key("sam.test@gmail.com"), "samtest@gmail.com")
        self.assertEqual(clean.email_key("samtest@googlemail.com"), "samtest@gmail.com")
        self.assertEqual(clean.email_key("sam.test+food@gmail.com"), "samtest@gmail.com")

    def test_other_providers_unchanged(self):
        self.assertEqual(clean.email_key("sam.test@example.org"), "sam.test@example.org")


class PhoneTest(unittest.TestCase):
    def test_formats_people_use(self):
        for raw in ["07700 900123", "07700-900123", "(07700) 900123",
                    "+44 7700 900123", "+44 (0)7700 900123", " 447700900123 "]:
            self.assertEqual(clean.normalise_phone(raw), "+447700900123", raw)

    def test_landline(self):
        self.assertEqual(clean.normalise_phone("020 7946 0018"), "+442079460018")

    def test_unrecognised_left_alone(self):
        self.assertEqual(clean.normalise_phone(" 12345 "), "12345")
        self.assertEqual(clean.normalise_phone(""), "")


def row(ts, name, email, phone, shifts="Sat AM"):
    return {"timestamp": ts, "full_name": name, "email": email,
            "phone": phone, "shifts": shifts, "notes": ""}


class DedupeTest(unittest.TestCase):
    def test_same_email_merges_and_keeps_newest(self):
        rows = [row("2026-10-01 09:00", "Sam Test", "sam@example.org", "+447700900001", "Sat AM"),
                row("2026-10-02 09:00", "Sam Test", "sam@example.org", "+447700900001", "Sun PM")]
        kept, merged, review = clean.dedupe(rows)
        self.assertEqual(kept, [rows[1]])
        self.assertEqual(len(merged), 1)
        self.assertEqual(review, [])

    def test_newest_wins_even_if_listed_first(self):
        rows = [row("2026-10-05 09:00", "Sam Test", "sam@example.org", "+447700900001", "Sun PM"),
                row("2026-10-01 09:00", "Sam Test", "sam@example.org", "+447700900001", "Sat AM")]
        kept, _, _ = clean.dedupe(rows)
        self.assertEqual(kept[0]["shifts"], "Sun PM")

    def test_same_phone_same_first_name_merges(self):
        rows = [row("2026-10-01 09:00", "Sam Test", "sam@example.org", "+447700900001"),
                row("2026-10-02 09:00", "Sam Tset", "sam.t@example.org", "+447700900001")]
        kept, merged, _ = clean.dedupe(rows)
        self.assertEqual(len(kept), 1)

    def test_shared_phone_different_first_names_goes_to_review(self):
        rows = [row("2026-10-01 09:00", "Jo Family", "jo@example.org", "+447700900001"),
                row("2026-10-02 09:00", "Joe Family", "joe@example.org", "+447700900001")]
        kept, merged, review = clean.dedupe(rows)
        self.assertEqual(kept, rows)
        self.assertEqual(merged, [])
        self.assertEqual(review, [rows])

    def test_same_gmail_written_differently_merges(self):
        rows = [row("2026-10-01 09:00", "Sam Test", "sam.test@gmail.com", "+447700900001"),
                row("2026-10-01 09:02", "Sam Test", "samtest@googlemail.com", "+447700900002")]
        kept, _, _ = clean.dedupe(rows)
        self.assertEqual(kept, [rows[1]])

    def test_similar_names_alone_do_not_merge(self):
        rows = [row("2026-10-01 09:00", "Chris Test", "a@example.org", "+447700900001"),
                row("2026-10-02 09:00", "Chris Tests", "b@example.org", "+447700900002")]
        kept, _, _ = clean.dedupe(rows)
        self.assertEqual(len(kept), 2)


class SampleTest(unittest.TestCase):
    def test_sample_loads_and_cleans(self):
        rows = clean.clean_rows(clean.load(SAMPLE))
        self.assertEqual(len(rows), 5)
        self.assertEqual(rows[1]["full_name"], "Test Person Two")
        self.assertEqual([r["phone"] for r in rows],
                         ["+447700900001", "+447700900002", "+447700900001",
                          "+447700900003", "+447700900004"])

    def test_sample_dedupes_to_four(self):
        kept, merged, review = clean.dedupe(clean.clean_rows(clean.load(SAMPLE)))
        self.assertEqual([r["full_name"] for r in kept],
                         ["Test Person Two", "Test Person One",
                          "Test Person Three", "Test Person Four"])
        self.assertEqual(kept[1]["timestamp"], "2026-10-02 10:00")
        self.assertEqual(review, [])


if __name__ == "__main__":
    unittest.main()
